'use strict';
module.exports = (bot, err) => {
    console.error(err);
};
