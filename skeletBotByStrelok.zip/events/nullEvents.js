module.exports = async (bot) => { //После "bot" могут быть аргументы. Например: для messageCreate - (bot,message). 
    //Тело ивента
};