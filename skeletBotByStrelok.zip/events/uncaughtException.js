'use strict';
module.exports = (bot, err) => {
    console.error(err);
    process.exit(1);
};