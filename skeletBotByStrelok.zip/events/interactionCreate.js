module.exports = async (bot, interaction) => {

};