module.exports = async (bot, message) => {
    
};